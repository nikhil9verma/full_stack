import axios from "axios";

const API = "http://localhost:8080";

export const getEvents = () => axios.get(`${API}/getevents`);
export const createEvent = (event) => axios.post(`${API}/event`, event);
export const deleteEvent = (id) => axios.delete(`${API}/${id}`);
