export default function EventCard({ event, onDelete }) {
  return (
    <div className="bg-white shadow-md rounded-lg p-5">
      <h2 className="text-lg font-semibold">{event.venue}</h2>
      <p className="text-gray-600">{event.description}</p>
      <p className="text-sm text-gray-500 mt-2">{event.date}</p>

      <button
        onClick={() => onDelete(event.id)}
        className="mt-3 bg-red-500 text-white px-4 py-1 rounded hover:bg-red-600"
      >
        Delete
      </button>
    </div>
  );
}
