import { useState } from "react";
import { createEvent } from "../services/eventService";

export default function EventForm() {
  const [event, setEvent] = useState({
    venue: "",
    date: "",
    description: ""
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await createEvent(event);
    alert("Event Created!");
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="max-w-md mx-auto bg-white p-6 shadow rounded"
    >
      <h2 className="text-xl font-bold mb-4">Create Event</h2>

      <input
        type="text"
        placeholder="Venue"
        className="w-full border p-2 mb-3 rounded"
        onChange={(e) => setEvent({ ...event, venue: e.target.value })}
      />

      <input
        type="date"
        className="w-full border p-2 mb-3 rounded"
        onChange={(e) => setEvent({ ...event, date: e.target.value })}
      />

      <textarea
        placeholder="Description"
        className="w-full border p-2 mb-3 rounded"
        onChange={(e) => setEvent({ ...event, description: e.target.value })}
      />

      <button className="w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700">
        Submit
      </button>
    </form>
  );
}
