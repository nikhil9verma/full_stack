import EventForm from "../components/EventForm";

export default function CreateEvent() {
  return (
    <div className="p-6">
      <EventForm />
    </div>
  );
}
