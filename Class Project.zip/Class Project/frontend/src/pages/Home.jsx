import { useEffect, useState } from "react";
import { getEvents, deleteEvent } from "../services/eventService";
import EventCard from "../components/EventCard";

export default function Home() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    loadEvents();
  }, []);

  const loadEvents = async () => {
    const res = await getEvents();
    setEvents(res.data);
  };

  const handleDelete = async (id) => {
    await deleteEvent(id);
    loadEvents();
  };

  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
      {events.map((event) => (
  <EventCard
    key={event.id}
    event={event}
    onDelete={handleDelete}
  />
))}

    </div>
  );
}