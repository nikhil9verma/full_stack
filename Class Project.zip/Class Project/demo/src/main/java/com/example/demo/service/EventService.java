package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.model.Event;
import com.example.demo.repository.EventRepository;

@Service
public class EventService {

    @Autowired
    private EventRepository repository;

    // Create
    public Event createEvent(Event event) {
        return repository.save(event);
    }

    // Read - All
    public List<Event> getAllEvents() {
        return repository.findAll();
    }

    // Read - By ID
    public Optional<Event> getEventById(Long id) {
        return repository.findById(id);
    }

    // Update
    public Event updateEvent(Long id, Event updatedEvent) {
        return repository.findById(id)
                .map(event -> {
                    event.setVenue(updatedEvent.getVenue());
                    event.setDate(updatedEvent.getDate());
                    event.setDescription(updatedEvent.getDescription());
                    // add other fields as required
                    return repository.save(event);
                })
                .orElseThrow(() -> new RuntimeException("Event not found with id: " + id));
    }

    public void deleteEvent(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Event not found with id: " + id);
        }
        repository.deleteById(id);
    }

    public List<Event> getEventsSorted(String field, String direction) {
        Sort sort = Sort.by(field).ascending();
        return repository.findAll(sort);
    }

    // Pagination
    public Page<Event> getEventsWithPagination(String field, int page, int size) {
        Sort sort = Sort.by(field).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return repository.findAll(pageable);
    }

}
